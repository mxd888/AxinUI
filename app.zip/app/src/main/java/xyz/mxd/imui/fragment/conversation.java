package xyz.mxd.imui.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;

import xyz.mxd.imui.R;
import xyz.mxd.imui.activity.AboutIMActivity;
import xyz.mxd.imui.activity.ChatActivity;


public class conversation extends Fragment implements View.OnClickListener{


    private ConstraintLayout id;

    // 初始化 view
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = View.inflate(getActivity(), R.layout.fragment_conversation, null);

        initView(view);
        initListener();
        return view;
    }

    private void initListener() {
        id.setOnClickListener(this);
    }

    private void initView(View view) {

        TextView lblTitle=(TextView)view.findViewById(R.id.common_toolbar_title);
        lblTitle.setText("会话");
        ImageView image_left = view.findViewById(R.id.image_left);
        image_left.setVisibility(View.GONE);

        id = view.findViewById(R.id.list_itease_layout);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.list_itease_layout:
                Intent intent = new Intent(getActivity(), ChatActivity.class);

                startActivity(intent);
                break;
        }

    }

}
