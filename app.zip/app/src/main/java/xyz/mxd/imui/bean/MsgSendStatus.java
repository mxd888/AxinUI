package xyz.mxd.imui.bean;

public enum MsgSendStatus {
    DEFAULT,
    //发送中
    SENDING,
    //发送失败
    FAILED,
    //已发送
    SENT;



}
