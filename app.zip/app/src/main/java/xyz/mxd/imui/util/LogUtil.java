package xyz.mxd.imui.util;

import android.util.Log;

public   class LogUtil {

    public static void d(String msg) {
        Log.d("chatui", msg);
     }
}
