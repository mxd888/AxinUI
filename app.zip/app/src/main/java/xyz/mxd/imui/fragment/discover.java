package xyz.mxd.imui.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;

import xyz.mxd.imui.R;
import xyz.mxd.imui.util.ToastUtils;
import xyz.mxd.imui.widget.ArrowItemView;

public class discover  extends Fragment implements View.OnClickListener{


    private ConstraintLayout clUserFriendShare;
    private ConstraintLayout clConversationMenuShi;
    private ArrowItemView itemConversationMenuScan;
    private ArrowItemView itemConversationMenuYao;
    private ArrowItemView itemConversationMenuKan;
    private ArrowItemView itemConversationMenuSou;

    // 初始化 view
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = View.inflate(getActivity(), R.layout.fragment_discover, null);

        initView(view);
        initListener();
        return view;
    }



    private void initView(View view) {

        // 调整 titlebar
        TextView lblTitle=(TextView)view.findViewById(R.id.common_toolbar_title);
        lblTitle.setText("发现");
        ImageView image_left = view.findViewById(R.id.image_left);
        image_left.setVisibility(View.GONE);



        clUserFriendShare = view.findViewById(R.id.cl_user_friend_share);
        clConversationMenuShi = view.findViewById(R.id.cl_conversation_menu_shi);
        itemConversationMenuScan = view.findViewById(R.id.item_conversation_menu_scan);
        itemConversationMenuYao = view.findViewById(R.id.item_conversation_menu_yao);
        itemConversationMenuKan = view.findViewById(R.id.item_conversation_menu_kan);
        itemConversationMenuSou = view.findViewById(R.id.item_conversation_menu_sou);
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.cl_user_friend_share:
                ToastUtils.showToast("顶部导航里面有(*^▽^*)",getActivity());
                break;
            case R.id.cl_conversation_menu_shi:
                ToastUtils.showToast("顶部导航里面有(*^▽^*)",getActivity());
                break;
            case R.id.item_conversation_menu_scan:
                ToastUtils.showToast("顶部导航里面有(*^▽^*)",getActivity());
                break;
            case R.id.item_conversation_menu_yao:
                ToastUtils.showToast("顶部导航里面有(*^▽^*)",getActivity());
                break;
            case R.id.item_conversation_menu_kan:
                ToastUtils.showToast("顶部导航里面有(*^▽^*)",getActivity());
                break;
            case R.id.item_conversation_menu_sou:
                ToastUtils.showToast("顶部导航里面有(*^▽^*)",getActivity());
                break;

        }

    }


    protected void initListener() {
        clUserFriendShare.setOnClickListener(this);
        clConversationMenuShi.setOnClickListener(this);
        itemConversationMenuScan.setOnClickListener(this);
        itemConversationMenuYao.setOnClickListener(this);
        itemConversationMenuKan.setOnClickListener(this);
        itemConversationMenuSou.setOnClickListener(this);
    }


}
