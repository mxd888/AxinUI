package xyz.mxd.imui.util;



import android.content.Context;

import com.lxj.xpopup.XPopup;
import com.lxj.xpopup.interfaces.OnConfirmListener;



import static java.security.AccessController.getContext;

/**
 * Toast工具类，统一Toast样式，处理重复显示的问题，处理7.1.x版本crash的问题
 */
public class ToastUtils {


    public static void showToast(String s, Context context) {

        new XPopup.Builder(context).asConfirm("温馨提示", s,
                new OnConfirmListener() {
                    @Override
                    public void onConfirm() {
                        //  ok  do thing
                    }
                })
                .show();

    }
}
