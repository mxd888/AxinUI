package xyz.mxd.imui.activity;

import androidx.annotation.IdRes;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.roughike.bottombar.BottomBar;
import com.roughike.bottombar.OnTabSelectListener;

import xyz.mxd.imui.R;
import xyz.mxd.imui.fragment.conversation;
import xyz.mxd.imui.fragment.discover;
import xyz.mxd.imui.fragment.friend;
import xyz.mxd.imui.fragment.mine;

public class MainActivity extends FragmentActivity {

    private conversation conversation;
    private discover discover;
    private friend friend;
    private mine mine;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initFragment();


        BottomBar bottomBar = (BottomBar) findViewById(R.id.bottomBar);
        bottomBar.setOnTabSelectListener(new OnTabSelectListener() {
            @Override
            public void onTabSelected(@IdRes int tabId) {
                // 创建 主fragment
                Fragment fragment = null;
                if (tabId == R.id.tab_conversation) {
                    fragment = conversation;
                }else if (tabId == R.id.tab_friends) {
                    fragment = friend;
                }else if (tabId == R.id.tab_discover) {
                    fragment = discover;
                }else if(tabId == R.id.tab_me) {
                    fragment = mine;
                }

                switchFragment(fragment);

            }
        });

    }

    private void switchFragment(Fragment fragment) {
        // 将fragment 替换成 指定 fragment
        getSupportFragmentManager().beginTransaction().replace(R.id.contentContainer,fragment).commit();
    }

    private void initFragment() {
        // 创建四个fragment对象
        // 会话
        conversation = new conversation();
        // 发现
        discover = new discover();
        // 好友列表
        friend = new friend();
        // 个人中心
        mine = new mine();
    }
}
