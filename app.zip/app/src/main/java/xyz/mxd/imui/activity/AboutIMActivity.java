package xyz.mxd.imui.activity;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import butterknife.BindView;
import xyz.mxd.imui.BuildConfig;
import xyz.mxd.imui.R;
import xyz.mxd.imui.widget.ArrowItemView;


public class AboutIMActivity extends AppCompatActivity implements View.OnClickListener{
//    private EaseTitleBar title_bar;
//    @BindView(R.id.tv_version)
    TextView tv_version;
//    @BindView(R.id.item_product)
    ArrowItemView item_product;
//    @BindView(R.id.item_company)
    ArrowItemView item_company;

    private ImageView image_left;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_im);
        initView();
        initData();
        initListener();
        getLayoutId();
    }

    private void initView() {

        tv_version = (TextView)findViewById(R.id.tv_version);
        item_product = findViewById(R.id.item_product);
        item_company = findViewById(R.id.item_company);
        image_left = findViewById(R.id.image_left);

        TextView lblTitle=(TextView) findViewById(R.id.common_toolbar_title);
        lblTitle.setText("A信");


    }


    protected int getLayoutId() {
        return R.layout.activity_about_im;
    }



    protected void initData() {

        tv_version.setText(getString(R.string.about_im_version, BuildConfig.VERSION_NAME));
    }

    protected void initListener() {
//        title_bar.setOnBackPressListener(this);
        item_product.setOnClickListener(this);
        item_company.setOnClickListener(this);
        image_left.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.item_product :
                jumpToIMIntroduction();
                break;
            case R.id.item_company :
                jumpToCompanyIntroduction();
                break;
            case R.id.image_left :
                finish();
                break;
        }
    }

    private void jumpToIMIntroduction() {
        Uri uri = Uri.parse("https://www.layui.com/");
        Intent it = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(it);
    }

    private void jumpToCompanyIntroduction() {
        Uri uri = Uri.parse("https://www.layui.com/");
        Intent it = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(it);
    }



//    @Override
//    public void onBackPress(View view) {
//        onBackPressed();
//    }
}
