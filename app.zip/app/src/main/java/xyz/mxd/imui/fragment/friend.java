package xyz.mxd.imui.fragment;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import xyz.mxd.imui.R;
import xyz.mxd.imui.fragment.friendFragment.ContactAdapter;
import xyz.mxd.imui.fragment.friendFragment.DividerItemDecoration;
import xyz.mxd.imui.fragment.friendFragment.LetterView;

public class friend extends Fragment {

    private RecyclerView contactList;
    private String[] contactNames;
    private LinearLayoutManager layoutManager;
    private LetterView letterView;
    private ContactAdapter adapter;
    private Context context;



    // 初始化 view
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        context = getActivity();
        View view = View.inflate(context, R.layout.fragment_friend, null);

        initView(view);
        return view;
    }

    private void initView(View view) {

        TextView lblTitle=(TextView)view.findViewById(R.id.common_toolbar_title);
        lblTitle.setText("通讯录");
        ImageView image_left = view.findViewById(R.id.image_left);
        image_left.setVisibility(View.GONE);

        contactNames = new String[] {"A张三丰", "郭靖", "黄蓉", "黄老邪", "赵敏", "123", "天山童姥", "任我行", "于万亭", "陈家洛", "韦小宝", "$6", "穆人清", "陈圆圆", "郭芙", "郭襄", "穆念慈", "东方不败", "梅超风", "林平之", "林远图", "灭绝师太", "段誉", "鸠摩智"};
        contactList = (RecyclerView) view.findViewById(R.id.contact_list);
        letterView = (LetterView) view.findViewById(R.id.letter_view);
        layoutManager = new LinearLayoutManager(context);
        adapter = new ContactAdapter(context, contactNames);

        contactList.setLayoutManager(layoutManager);
        contactList.addItemDecoration(new DividerItemDecoration(context, xyz.mxd.imui.fragment.friendFragment.DividerItemDecoration.VERTICAL_LIST));
        contactList.setAdapter(adapter);

        letterView.setCharacterListener(new LetterView.CharacterClickListener() {
            @Override
            public void clickCharacter(String character) {
                layoutManager.scrollToPositionWithOffset(adapter.getScrollPosition(character),0);
            }

            @Override
            public void clickArrow() {
                layoutManager.scrollToPositionWithOffset(0,0);
            }
        });

    }

}
